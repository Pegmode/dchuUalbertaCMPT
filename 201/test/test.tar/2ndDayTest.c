//2nd class example program
#include <stdio.h>

int main() {
	int n;
	scanf("%d",&n);
	int product =1;
	for (int i = i; i<= n; i++) {
		product = product * i;
	}
	printf("factorial = %d", product);
	return 0;
}
