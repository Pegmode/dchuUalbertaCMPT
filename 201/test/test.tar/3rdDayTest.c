#include <stdio.h>
int main(){
  float i;
  i = 839.32f;
  printf("%10.6f\n",i);
  printf("The quick brown fox\n");
  return 0;
}
