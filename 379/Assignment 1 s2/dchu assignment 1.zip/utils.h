typedef struct CommandContainer CommandContainer;
typedef struct Process Process;
typedef struct ProcessTable ProcessTable;

struct PTableLookupResult{
    bool isFound;
    int position;
};